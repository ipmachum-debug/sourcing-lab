/* ============================================================
   Coupang Sourcing Helper — Side Panel Logic v3.5
   분석 · 경쟁도 · 1688 · 후보 · 순위추적 · 상세파싱 · 마진
   ============================================================ */

// ---- State ----
let currentData = null;
let currentItems = [];
let currentDetail = null;

// ---- DOM refs ----
const $ = (s) => document.querySelector(s);
const $$ = (s) => document.querySelectorAll(s);

// ---- Tab 관리 ----
$$('.tab').forEach(btn => {
  btn.addEventListener('click', () => {
    $$('.tab').forEach(t => t.classList.remove('active'));
    $$('.tab-content').forEach(c => c.classList.remove('active'));
    btn.classList.add('active');
    $(`#tab-${btn.dataset.tab}`).classList.add('active');
    if (btn.dataset.tab === 'candidates') loadCandidates();
    if (btn.dataset.tab === 'history') loadHistory();
    if (btn.dataset.tab === 'ranking') loadRankingTab();
    if (btn.dataset.tab === 'detail') loadDetailTab();
  });
});

// ============================================================
//  유틸
// ============================================================

function formatPrice(n) {
  if (!n) return '-';
  return n.toLocaleString('ko-KR') + '원';
}

function calcSourcingScore(item, avgPrice, avgReview) {
  let score = 50;
  if (item.reviewCount === 0) score += 25;
  else if (item.reviewCount < 10) score += 20;
  else if (item.reviewCount < 50) score += 10;
  else if (item.reviewCount < 100) score += 5;
  else if (item.reviewCount > 500) score -= 15;
  else if (item.reviewCount > 1000) score -= 25;
  if (item.rating > 0 && item.rating < 3.5) score += 10;
  else if (item.rating >= 4.5) score -= 5;
  if (avgPrice > 0 && item.price > 0) {
    const priceRatio = item.price / avgPrice;
    if (priceRatio > 1.3) score += 15;
    else if (priceRatio > 1.1) score += 8;
    else if (priceRatio < 0.7) score -= 10;
  }
  if (item.isAd) score -= 10;
  if (item.isRocket) score -= 5;
  return Math.max(0, Math.min(100, score));
}

function getSourcingGrade(score) {
  if (score >= 80) return { grade: 'A', label: '매우 좋음', cls: 'grade-a' };
  if (score >= 65) return { grade: 'B', label: '좋음', cls: 'grade-b' };
  if (score >= 50) return { grade: 'C', label: '보통', cls: 'grade-c' };
  if (score >= 35) return { grade: 'D', label: '어려움', cls: 'grade-d' };
  return { grade: 'F', label: '매우 어려움', cls: 'grade-f' };
}

function extractKeyword(title) {
  if (!title) return '';
  let cleaned = title.replace(/\[.*?\]/g, '').replace(/\(.*?\)/g, '').replace(/[^\uAC00-\uD7A3a-zA-Z0-9\s]/g, '').trim();
  const words = cleaned.split(/\s+/).filter(w => w.length > 1);
  return words.slice(0, 4).join(' ');
}

async function getActiveTab() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  return tabs[0] || null;
}

async function getResults(tabId) {
  return chrome.runtime.sendMessage({ type: 'GET_RESULTS_FOR_TAB', tabId });
}

// ============================================================
//  분석 탭
// ============================================================

function analyzeCompetition(items) {
  if (!items.length) return null;
  const prices = items.map(i => i.price).filter(p => p > 0);
  const reviews = items.map(i => i.reviewCount).filter(r => r > 0);
  const ratings = items.map(i => i.rating).filter(r => r > 0);
  const avgPrice = prices.length ? Math.round(prices.reduce((a, b) => a + b, 0) / prices.length) : 0;
  const avgReview = reviews.length ? Math.round(reviews.reduce((a, b) => a + b, 0) / reviews.length) : 0;
  const avgRating = ratings.length ? (ratings.reduce((a, b) => a + b, 0) / ratings.length).toFixed(1) : 0;
  const highReviewCount = items.filter(i => i.reviewCount >= 100).length;
  const highReviewRatio = Math.round((highReviewCount / items.length) * 100);
  const adCount = items.filter(i => i.isAd).length;

  let competitionScore = 0;
  if (avgReview > 1000) competitionScore += 40;
  else if (avgReview > 500) competitionScore += 30;
  else if (avgReview > 100) competitionScore += 20;
  else if (avgReview > 30) competitionScore += 10;
  if (highReviewRatio > 60) competitionScore += 25;
  else if (highReviewRatio > 40) competitionScore += 15;
  else if (highReviewRatio > 20) competitionScore += 8;
  if (avgRating >= 4.5) competitionScore += 15;
  else if (avgRating >= 4.0) competitionScore += 8;
  const adRatio = adCount / items.length;
  if (adRatio > 0.3) competitionScore += 20;
  else if (adRatio > 0.15) competitionScore += 10;

  let level, levelText, levelCls;
  if (competitionScore >= 70) { level = '강함'; levelText = '경쟁이 매우 치열합니다. 차별화 전략이 필요합니다.'; levelCls = 'level-hard'; }
  else if (competitionScore >= 45) { level = '보통'; levelText = '경쟁이 있지만 진입 가능합니다.'; levelCls = 'level-medium'; }
  else { level = '약함'; levelText = '경쟁이 낮습니다. 소싱 기회!'; levelCls = 'level-easy'; }

  return { competitionScore, level, levelText, levelCls, avgPrice, avgReview, avgRating, highReviewRatio, adCount, totalItems: items.length };
}

function renderItems(items, comp) {
  const results = $('#results');
  const tpl = $('#itemTemplate');
  results.innerHTML = '';
  if (!items.length) { results.innerHTML = '<li class="empty-msg">표시할 상품이 없습니다.</li>'; return; }

  const avgPrice = comp?.avgPrice || 0;
  const avgReview = comp?.avgReview || 0;

  for (const item of items) {
    const node = tpl.content.cloneNode(true);
    const img = node.querySelector('.item-img');
    if (item.imageUrl) { img.src = item.imageUrl; img.alt = item.title; } else { img.style.display = 'none'; }

    const badges = node.querySelector('.item-badges');
    let badgeHtml = `<span class="badge-rank">#${item.position}</span>`;
    if (item.isAd) badgeHtml += '<span class="badge-ad">AD</span>';
    if (item.isRocket) badgeHtml += '<span class="badge-rocket">🚀</span>';
    badges.innerHTML = badgeHtml;

    node.querySelector('.title').textContent = item.title || '(제목 없음)';
    node.querySelector('.price-line').textContent = item.price ? formatPrice(item.price) : '-';
    node.querySelector('.meta-line').textContent = `평점 ${item.rating || '-'} · 리뷰 ${item.reviewCount?.toLocaleString() || '0'}개`;

    const sourcingScore = calcSourcingScore(item, avgPrice, avgReview);
    item._sourcingScore = sourcingScore;
    const grade = getSourcingGrade(sourcingScore);
    item._sourcingGrade = grade.grade;
    const scoreEl = node.querySelector('.score-value');
    scoreEl.textContent = `${grade.grade} (${sourcingScore}점)`;
    scoreEl.className = `score-value ${grade.cls}`;

    node.querySelector('.btn-1688').addEventListener('click', () => {
      const keyword = extractKeyword(item.title);
      chrome.tabs.create({ url: `https://s.1688.com/selloffer/offer_search.htm?keywords=${encodeURIComponent(keyword)}` });
    });

    const saveBtn = node.querySelector('.btn-save');
    saveBtn.addEventListener('click', async () => {
      await chrome.runtime.sendMessage({ type: 'SAVE_CANDIDATE', item });
      saveBtn.textContent = '✅';
      saveBtn.disabled = true;
    });

    // 순위 추적 버튼
    node.querySelector('.btn-track').addEventListener('click', async () => {
      const query = currentData?.query || '';
      if (!query) { alert('검색어를 감지할 수 없습니다.'); return; }
      await chrome.runtime.sendMessage({
        type: 'ADD_TRACKED_KEYWORD',
        keyword: { query, targetProductId: item.productId, targetProductName: item.title }
      });
      alert(`"${query}" 키워드 순위 추적이 등록되었습니다.`);
    });

    node.querySelector('.btn-link').href = item.url;
    results.appendChild(node);
  }
}

function getFilteredSorted() {
  if (!currentData?.items) return [];
  let items = [...currentData.items];
  if ($('#filterNoAd').checked) items = items.filter(i => !i.isAd);
  if ($('#filterEasySourcing').checked) {
    const comp = analyzeCompetition(currentData.items);
    items.forEach(i => { i._sourcingScore = calcSourcingScore(i, comp?.avgPrice || 0, comp?.avgReview || 0); });
    items = items.filter(i => i._sourcingScore >= 60);
  }
  const topN = parseInt($('#topNSelect').value) || 0;
  if (topN > 0) items = items.slice(0, topN);
  const sort = $('#sortSelect').value;
  switch (sort) {
    case 'price-asc': items.sort((a, b) => (a.price || 0) - (b.price || 0)); break;
    case 'price-desc': items.sort((a, b) => (b.price || 0) - (a.price || 0)); break;
    case 'review-desc': items.sort((a, b) => (b.reviewCount || 0) - (a.reviewCount || 0)); break;
    case 'rating-desc': items.sort((a, b) => (b.rating || 0) - (a.rating || 0)); break;
    case 'sourcing-desc': {
      const comp = analyzeCompetition(currentData.items);
      items.forEach(i => { i._sourcingScore = calcSourcingScore(i, comp?.avgPrice || 0, comp?.avgReview || 0); });
      items.sort((a, b) => (b._sourcingScore || 0) - (a._sourcingScore || 0));
      break;
    }
  }
  return items;
}

function renderAnalysis(data) {
  currentData = data;
  if (!data || !data.items?.length) {
    $('#summary').textContent = '쿠팡 검색 결과 페이지를 열면 자동 분석됩니다.';
    $('#competitionCard').style.display = 'none';
    $('#statsGrid').style.display = 'none';
    $('#filterBar').style.display = 'none';
    $('#results').innerHTML = '';
    return;
  }
  $('#summary').textContent = `"${data.query || '-'}" · ${data.count}개 · ${new Date(data.capturedAt).toLocaleTimeString('ko-KR')}`;

  const comp = analyzeCompetition(data.items);
  if (comp) {
    $('#competitionCard').style.display = '';
    $('#competitionBadge').textContent = `${comp.level} (${comp.competitionScore}점)`;
    $('#competitionBadge').className = `competition-badge ${comp.levelCls}`;
    $('#competitionDetails').innerHTML = `<div>${comp.levelText}</div><div class="comp-stats">상품 ${comp.totalItems}개 · 광고 ${comp.adCount}개 · 리뷰100+ ${comp.highReviewRatio}%</div>`;
    $('#statsGrid').style.display = '';
    $('#statAvgPrice').textContent = formatPrice(comp.avgPrice);
    $('#statAvgRating').textContent = comp.avgRating || '-';
    $('#statAvgReview').textContent = comp.avgReview?.toLocaleString() || '-';
    $('#statHighReviewRatio').textContent = comp.highReviewRatio + '%';
  }
  $('#filterBar').style.display = '';
  renderItems(getFilteredSorted(), comp);
}

$('#sortSelect').addEventListener('change', () => renderAnalysis(currentData));
$('#filterNoAd').addEventListener('change', () => renderAnalysis(currentData));
$('#filterEasySourcing').addEventListener('change', () => renderAnalysis(currentData));
$('#topNSelect').addEventListener('change', () => renderAnalysis(currentData));

// ============================================================
//  후보 탭
// ============================================================

async function loadCandidates() {
  const resp = await chrome.runtime.sendMessage({ type: 'GET_CANDIDATES' });
  const candidates = resp?.data || [];
  const list = $('#candidateList');
  const tpl = $('#candidateTemplate');
  const empty = $('#candidateEmpty');
  list.innerHTML = '';
  $('#candidateCount').textContent = candidates.length;
  if (!candidates.length) { empty.style.display = ''; return; }
  empty.style.display = 'none';
  for (const item of candidates) {
    const node = tpl.content.cloneNode(true);
    const img = node.querySelector('.item-img');
    if (item.imageUrl) { img.src = item.imageUrl; img.alt = item.title; } else img.style.display = 'none';
    node.querySelector('.title').textContent = item.title;
    node.querySelector('.price-line').textContent = item.price ? formatPrice(item.price) : '-';
    node.querySelector('.meta-line').textContent = `평점 ${item.rating || '-'} · 리뷰 ${item.reviewCount?.toLocaleString() || '0'}개 · ${new Date(item.savedAt).toLocaleDateString('ko-KR')}`;
    node.querySelector('.btn-1688').addEventListener('click', () => {
      chrome.tabs.create({ url: `https://s.1688.com/selloffer/offer_search.htm?keywords=${encodeURIComponent(extractKeyword(item.title))}` });
    });
    node.querySelector('.btn-remove').addEventListener('click', async () => {
      await chrome.runtime.sendMessage({ type: 'REMOVE_CANDIDATE', productId: item.productId });
      loadCandidates();
    });
    node.querySelector('.btn-link').href = item.url;
    list.appendChild(node);
  }
}

// ============================================================
//  순위 추적 탭
// ============================================================

async function loadRankingTab() {
  const resp = await chrome.runtime.sendMessage({ type: 'GET_TRACKED_KEYWORDS' });
  const keywords = resp?.data || [];
  const list = $('#trackedKeywordsList');
  const empty = $('#rankingEmpty');
  list.innerHTML = '';

  if (!keywords.length) { empty.style.display = ''; $('#rankDetailCard').style.display = 'none'; return; }
  empty.style.display = 'none';

  for (const kw of keywords) {
    const div = document.createElement('div');
    div.className = 'tracked-keyword-item';
    div.innerHTML = `
      <div class="tk-main">
        <span class="tk-query">"${kw.query}"</span>
        ${kw.targetProductId ? `<span class="tk-target">타겟: ${kw.targetProductName || kw.targetProductId}</span>` : ''}
      </div>
      <div class="tk-actions">
        <button class="btn-sm tk-view-btn">📊 보기</button>
        <button class="btn-sm tk-search-btn">🔍</button>
        <button class="btn-sm btn-remove tk-remove-btn">✕</button>
      </div>
    `;

    div.querySelector('.tk-view-btn').addEventListener('click', () => loadRankDetail(kw));
    div.querySelector('.tk-search-btn').addEventListener('click', () => {
      chrome.tabs.create({ url: `https://www.coupang.com/np/search?q=${encodeURIComponent(kw.query)}` });
    });
    div.querySelector('.tk-remove-btn').addEventListener('click', async () => {
      await chrome.runtime.sendMessage({ type: 'REMOVE_TRACKED_KEYWORD', keywordId: kw.query });
      loadRankingTab();
    });
    list.appendChild(div);
  }
}

async function loadRankDetail(kw) {
  const card = $('#rankDetailCard');
  card.style.display = '';
  $('#rankDetailTitle').textContent = `"${kw.query}" 순위`;

  const resp = await chrome.runtime.sendMessage({ type: 'GET_LATEST_RANKING', query: kw.query });
  const rankings = resp?.data || [];
  const content = $('#rankDetailContent');

  if (!rankings.length) {
    content.innerHTML = '<p class="empty-msg">아직 순위 데이터가 없습니다.<br/>쿠팡에서 이 키워드를 검색하면 자동으로 기록됩니다.</p>';
    $('#rankDetailCount').textContent = '0';
    return;
  }

  $('#rankDetailCount').textContent = rankings.length;
  let html = '<div class="rank-list">';
  for (const r of rankings) {
    const isTarget = kw.targetProductId && r.coupangProductId === kw.targetProductId;
    html += `
      <div class="rank-item ${isTarget ? 'rank-item-target' : ''}">
        <span class="rank-pos">#${r.position}</span>
        <div class="rank-info">
          <div class="rank-title">${r.title || r.coupangProductId}</div>
          <div class="rank-meta">${formatPrice(r.price)} · 리뷰 ${r.reviewCount} · 평점 ${r.rating}${r.isAd ? ' · <span class="badge-ad">AD</span>' : ''}${r.isRocket ? ' · 🚀' : ''}</div>
        </div>
        ${isTarget ? '<span class="badge-target">타겟</span>' : ''}
      </div>`;
  }
  html += '</div>';
  content.innerHTML = html;
}

// 추적 키워드 추가
$('#addRankKeywordBtn').addEventListener('click', async () => {
  const query = $('#rankKeywordInput').value.trim();
  const targetId = $('#rankProductIdInput').value.trim();
  if (!query) { alert('키워드를 입력하세요.'); return; }
  await chrome.runtime.sendMessage({
    type: 'ADD_TRACKED_KEYWORD',
    keyword: { query, targetProductId: targetId || null, targetProductName: null }
  });
  $('#rankKeywordInput').value = '';
  $('#rankProductIdInput').value = '';
  loadRankingTab();
});

// ============================================================
//  상품 상세 탭
// ============================================================

async function loadDetailTab() {
  // 현재 탭이 상품 상세 페이지인 경우 자동 로드
  const tab = await getActiveTab();
  if (!tab?.url?.includes('/vp/products/')) {
    // 마지막으로 파싱된 상세 있는지 확인
    if (currentDetail) {
      renderDetail(currentDetail);
    } else {
      $('#detailCard').style.display = 'none';
      $('#detailEmpty').style.display = '';
    }
    return;
  }

  // 상품 ID 추출
  const m = tab.url.match(/\/vp\/products\/(\d+)/);
  if (m) {
    const resp = await chrome.runtime.sendMessage({ type: 'GET_PRODUCT_DETAIL', productId: m[1] });
    if (resp?.data) {
      renderDetail(resp.data);
    }
  }
}

function renderDetail(detail) {
  if (!detail) return;
  currentDetail = detail;
  $('#detailCard').style.display = '';
  $('#detailEmpty').style.display = 'none';

  if (detail.imageUrl) {
    $('#detailImg').src = detail.imageUrl;
    $('#detailImg').style.display = '';
  } else {
    $('#detailImg').style.display = 'none';
  }
  $('#detailTitle').textContent = detail.title || '-';
  $('#detailPrice').textContent = detail.price ? formatPrice(detail.price) : '-';

  let metaParts = [];
  if (detail.rating) metaParts.push(`평점 ${detail.rating}`);
  if (detail.reviewCount) metaParts.push(`리뷰 ${detail.reviewCount.toLocaleString()}`);
  if (detail.purchaseCount) metaParts.push(detail.purchaseCount);
  $('#detailMeta').textContent = metaParts.join(' · ');

  // 상세 그리드
  const grid = $('#detailGrid');
  let gridHtml = '';
  const items = [
    { label: '판매자', value: detail.sellerName || '-' },
    { label: '카테고리', value: detail.categoryPath || '-' },
    { label: '원래가격', value: detail.originalPrice ? formatPrice(detail.originalPrice) : '-' },
    { label: '할인율', value: detail.discountRate ? detail.discountRate + '%' : '-' },
    { label: '로켓배송', value: detail.isRocket ? '✅' : '❌' },
    { label: '무료배송', value: detail.isFreeShipping ? '✅' : '❌' },
    { label: '옵션수', value: detail.optionCount || 0 },
  ];
  for (const d of items) {
    gridHtml += `<div class="detail-grid-item"><span class="dg-label">${d.label}</span><span class="dg-value">${d.value}</span></div>`;
  }
  grid.innerHTML = gridHtml;

  // 1688 버튼
  $('#detailBtn1688').onclick = () => {
    const keyword = extractKeyword(detail.title);
    chrome.tabs.create({ url: `https://s.1688.com/selloffer/offer_search.htm?keywords=${encodeURIComponent(keyword)}` });
  };

  // 후보 저장
  $('#detailBtnSave').onclick = async () => {
    await chrome.runtime.sendMessage({
      type: 'SAVE_CANDIDATE',
      item: {
        productId: detail.coupangProductId,
        title: detail.title,
        price: detail.price,
        rating: detail.rating,
        reviewCount: detail.reviewCount,
        imageUrl: detail.imageUrl,
        url: detail.url,
        query: '',
      }
    });
    $('#detailBtnSave').textContent = '✅ 저장됨';
    $('#detailBtnSave').disabled = true;
  };

  // 순위 추적
  $('#detailBtnTrack').onclick = async () => {
    const query = prompt('이 상품의 주요 검색 키워드를 입력하세요:', extractKeyword(detail.title));
    if (!query) return;
    await chrome.runtime.sendMessage({
      type: 'ADD_TRACKED_KEYWORD',
      keyword: { query, targetProductId: detail.coupangProductId, targetProductName: detail.title }
    });
    alert(`"${query}" 순위 추적이 등록되었습니다.`);
  };

  // 가격 변동 히스토리
  loadPriceHistory(detail.coupangProductId);
}

async function loadPriceHistory(productId) {
  const resp = await chrome.runtime.sendMessage({ type: 'GET_PRODUCT_PRICE_HISTORY', productId, days: 30 });
  const history = resp?.data || [];
  const section = $('#priceHistorySection');
  const content = $('#priceHistoryContent');

  if (!history.length) {
    section.style.display = 'none';
    return;
  }
  section.style.display = '';

  let html = '<div class="price-history-list">';
  for (const h of history.slice(0, 10)) {
    html += `
      <div class="ph-item">
        <span class="ph-date">${new Date(h.capturedAt).toLocaleDateString('ko-KR')}</span>
        <span class="ph-price">${formatPrice(h.price)}</span>
        <span class="ph-review">리뷰 ${h.reviewCount}</span>
        ${h.purchaseCount ? `<span class="ph-purchase">${h.purchaseCount}</span>` : ''}
      </div>`;
  }
  html += '</div>';
  content.innerHTML = html;
}

// ============================================================
//  히스토리 탭
// ============================================================

async function loadHistory() {
  const resp = await chrome.runtime.sendMessage({ type: 'GET_HISTORY' });
  const history = resp?.data || [];
  const list = $('#historyList');
  const empty = $('#historyEmpty');
  list.innerHTML = '';
  if (!history.length) { empty.style.display = ''; return; }
  empty.style.display = 'none';
  for (const h of history) {
    const li = document.createElement('li');
    li.className = 'history-item';
    li.innerHTML = `
      <div class="history-query">"${h.query}"</div>
      <div class="history-stats">${h.count}개 · 평균가 ${formatPrice(h.avgPrice)} · 평점 ${h.avgRating || '-'} · 리뷰 ${h.avgReview || '-'}</div>
      <div class="history-time">${new Date(h.timestamp).toLocaleString('ko-KR')}</div>`;
    li.addEventListener('click', () => {
      chrome.tabs.create({ url: `https://www.coupang.com/np/search?q=${encodeURIComponent(h.query)}` });
    });
    list.appendChild(li);
  }
}

$('#clearHistoryBtn').addEventListener('click', async () => {
  if (!confirm('검색 히스토리를 모두 삭제할까요?')) return;
  await chrome.runtime.sendMessage({ type: 'CLEAR_HISTORY' });
  loadHistory();
});

// ============================================================
//  마진 계산기
// ============================================================

$('#calcBtn').addEventListener('click', () => {
  const cnyCost = parseFloat($('#calcCnyCost').value) || 0;
  const exchangeRate = parseFloat($('#calcExchangeRate').value) || 190;
  const shipping = parseFloat($('#calcShipping').value) || 0;
  const taxRate = parseFloat($('#calcTaxRate').value) || 0;
  const salePrice = parseFloat($('#calcSalePrice').value) || 0;
  const commissionRate = parseFloat($('#calcCommission').value) || 0;

  const costKrw = Math.round(cnyCost * exchangeRate);
  const tax = Math.round(costKrw * (taxRate / 100));
  const totalCost = costKrw + shipping + tax;
  const commission = Math.round(salePrice * (commissionRate / 100));
  const profit = salePrice - totalCost - commission;
  const margin = salePrice > 0 ? ((profit / salePrice) * 100).toFixed(1) : 0;

  $('#calcResult').style.display = '';
  $('#resultCostKrw').textContent = formatPrice(costKrw);
  $('#resultShipping').textContent = formatPrice(shipping);
  $('#resultTax').textContent = formatPrice(tax);
  $('#resultTotalCost').textContent = formatPrice(totalCost);
  $('#resultCommission').textContent = formatPrice(commission);
  $('#resultProfit').textContent = formatPrice(profit);
  $('#resultMargin').textContent = margin + '%';

  const cls = profit > 0 ? 'profit-positive' : 'profit-negative';
  $('#profitRow').className = `calc-result-row profit-row ${cls}`;
  $('#marginRow').className = `calc-result-row margin-row ${cls}`;
});

// ============================================================
//  서버 연동 탭
// ============================================================

const statusLabels = {
  new: '신규', reviewing: '검토중', contacted_supplier: '공급처 연락',
  sample_ordered: '샘플 주문', dropped: '탈락', selected: '선정',
};

async function checkServerAuth() {
  try {
    const resp = await chrome.runtime.sendMessage({ type: 'SERVER_CHECK_AUTH' });
    if (resp?.ok && resp.loggedIn) { showLoggedIn(resp.user); return true; }
    showLoginForm();
    return false;
  } catch (e) { showLoginForm(); return false; }
}

function showLoggedIn(user) {
  $('#syncStatus').className = 'sync-status sync-connected';
  $('#syncStatus').title = '서버 연결됨';
  $('#serverLoginForm').style.display = 'none';
  $('#serverLoggedIn').style.display = '';
  $('#serverUserName').textContent = user?.name || '사용자';
  $('#serverUserEmail').textContent = user?.email || '';
  $('#serverStatusBadge').textContent = '연결됨';
  $('#serverStatusBadge').className = 'sync-indicator sync-connected';
  loadServerStats();
}

function showLoginForm() {
  $('#syncStatus').className = 'sync-status sync-disconnected';
  $('#syncStatus').title = '서버 미연결';
  $('#serverLoginForm').style.display = '';
  $('#serverLoggedIn').style.display = 'none';
  $('#serverStatusBadge').textContent = '미연결';
  $('#serverStatusBadge').className = 'sync-indicator sync-disconnected';
  $('#serverStatsCard').style.display = 'none';
}

$('#serverLoginBtn').addEventListener('click', async () => {
  const email = $('#serverEmail').value.trim();
  const password = $('#serverPassword').value;
  const errorEl = $('#serverLoginError');
  errorEl.style.display = 'none';
  if (!email || !password) { errorEl.textContent = '이메일과 비밀번호를 입력하세요.'; errorEl.style.display = ''; return; }
  const btn = $('#serverLoginBtn');
  btn.disabled = true; btn.textContent = '로그인 중...';
  try {
    const resp = await chrome.runtime.sendMessage({ type: 'SERVER_LOGIN', email, password });
    if (resp?.ok) { showLoggedIn(resp.user); }
    else { errorEl.textContent = resp?.error || '로그인 실패'; errorEl.style.display = ''; }
  } catch (e) { errorEl.textContent = e.message || '로그인 실패'; errorEl.style.display = ''; }
  finally { btn.disabled = false; btn.textContent = '로그인'; }
});

$('#serverLogoutBtn').addEventListener('click', async () => {
  await chrome.storage.local.set({ serverLoggedIn: false, serverEmail: '' });
  showLoginForm();
});

async function loadServerStats() {
  const statsCard = $('#serverStatsCard');
  try {
    const searchResp = await chrome.runtime.sendMessage({ type: 'SERVER_SEARCH_STATS' });
    const candResp = await chrome.runtime.sendMessage({ type: 'SERVER_CANDIDATE_STATS' });
    const searchData = searchResp?.data;
    const candData = candResp?.data;
    if (!searchData && !candData) { statsCard.style.display = 'none'; return; }

    statsCard.style.display = '';
    $('#srvTotalSearches').textContent = searchData?.totalSearches || 0;
    $('#srvUniqueQueries').textContent = searchData?.uniqueQueries || 0;
    $('#srvTotalCandidates').textContent = candData?.total || 0;
    $('#srvAvgScore').textContent = candData?.avgScore || '-';

    const topList = $('#srvTopQueries');
    topList.innerHTML = '';
    if (searchData?.topQueries?.length) {
      for (const q of searchData.topQueries) {
        const li = document.createElement('li');
        li.className = 'top-query-item';
        li.innerHTML = `<span class="tq-query">"${q.query}"</span><span class="tq-count">${q.count}회</span><span class="tq-comp">경쟁 ${q.avgCompetition || '-'}점</span>`;
        li.addEventListener('click', () => chrome.tabs.create({ url: `https://www.coupang.com/np/search?q=${encodeURIComponent(q.query)}` }));
        topList.appendChild(li);
      }
    } else { topList.innerHTML = '<li class="empty-msg">아직 검색 기록이 없습니다.</li>'; }

    const statusDiv = $('#srvStatusCounts');
    statusDiv.innerHTML = '';
    if (candData?.statusCounts?.length) {
      for (const s of candData.statusCounts) {
        const chip = document.createElement('span');
        chip.className = `status-chip status-${s.status}`;
        chip.textContent = `${statusLabels[s.status] || s.status} ${s.count}`;
        statusDiv.appendChild(chip);
      }
    } else { statusDiv.innerHTML = '<span class="empty-msg">후보 없음</span>'; }
  } catch (e) { statsCard.style.display = 'none'; }
}

// ============================================================
//  데이터 로드 & 실시간 업데이트
// ============================================================

async function refreshFromCurrentTab() {
  const tab = await getActiveTab();
  if (!tab?.id) return;
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => { document.dispatchEvent(new Event('visibilitychange')); }
    });
  } catch (e) { }
  const response = await getResults(tab.id);
  renderAnalysis(response?.data || null);
}

chrome.runtime.onMessage.addListener(async (message) => {
  if (message?.type === 'RESULTS_UPDATED') {
    const tab = await getActiveTab();
    if (tab?.id === message.tabId) {
      const response = await getResults(tab.id);
      renderAnalysis(response?.data || null);
    }
  }
  if (message?.type === 'DETAIL_UPDATED') {
    currentDetail = message.detail;
    // 상세 탭이 활성 상태면 자동 갱신
    if ($('#tab-detail').classList.contains('active')) {
      renderDetail(message.detail);
    }
  }
});

// ============================================================
//  CSV 내보내기
// ============================================================

function exportToCSV(items, query) {
  if (!items?.length) { alert('내보낼 데이터가 없습니다.'); return; }
  const comp = analyzeCompetition(items);
  const headers = ['순위', '상품명', '가격', '평점', '리뷰수', '소싱점수', '소싱등급', '광고', '로켓배송', 'URL'];
  const rows = items.map(item => {
    const score = calcSourcingScore(item, comp?.avgPrice || 0, comp?.avgReview || 0);
    const grade = getSourcingGrade(score);
    return [
      item.position,
      `"${(item.title || '').replace(/"/g, '""')}"`,
      item.price || 0,
      item.rating || 0,
      item.reviewCount || 0,
      score,
      grade.grade,
      item.isAd ? 'Y' : 'N',
      item.isRocket ? 'Y' : 'N',
      item.url || '',
    ].join(',');
  });
  const bom = '\uFEFF'; // UTF-8 BOM for Korean
  const csv = bom + headers.join(',') + '\n' + rows.join('\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `coupang_${(query || 'analysis').replace(/[^a-zA-Z0-9가-힣]/g, '_')}_${new Date().toISOString().slice(0, 10)}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

$('#exportCsvBtn').addEventListener('click', () => {
  exportToCSV(getFilteredSorted(), currentData?.query);
});

// ============================================================
//  환율 실시간 가져오기
// ============================================================

$('#fetchRateBtn').addEventListener('click', async () => {
  const btn = $('#fetchRateBtn');
  btn.disabled = true;
  btn.textContent = '⏳';
  try {
    // 공개 환율 API 사용
    const resp = await fetch('https://open.er-api.com/v6/latest/CNY');
    const data = await resp.json();
    if (data?.rates?.KRW) {
      const rate = Math.round(data.rates.KRW);
      $('#calcExchangeRate').value = rate;
      btn.textContent = '✅';
      setTimeout(() => { btn.textContent = '🔄'; btn.disabled = false; }, 2000);
    } else { throw new Error('환율 데이터 없음'); }
  } catch (e) {
    btn.textContent = '❌';
    setTimeout(() => { btn.textContent = '🔄'; btn.disabled = false; }, 2000);
    alert('환율 가져오기 실패. 네트워크를 확인하세요.');
  }
});

// ============================================================
//  마진 계산 결과 저장
// ============================================================

$('#exportMarginBtn').addEventListener('click', () => {
  const result = $('#calcResult');
  if (result.style.display === 'none') { alert('먼저 계산을 실행하세요.'); return; }
  const data = {
    date: new Date().toISOString().slice(0, 10),
    cnyCost: $('#calcCnyCost').value,
    exchangeRate: $('#calcExchangeRate').value,
    shipping: $('#calcShipping').value,
    taxRate: $('#calcTaxRate').value,
    salePrice: $('#calcSalePrice').value,
    commission: $('#calcCommission').value,
    costKrw: $('#resultCostKrw').textContent,
    totalCost: $('#resultTotalCost').textContent,
    profit: $('#resultProfit').textContent,
    margin: $('#resultMargin').textContent,
  };
  const bom = '\uFEFF';
  const csv = bom + Object.keys(data).join(',') + '\n' + Object.values(data).join(',');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `margin_calc_${data.date}.csv`;
  a.click();
  URL.revokeObjectURL(url);
});

// ============================================================
//  가이드 탭 — 아코디언 토글
// ============================================================

$$('[data-guide-toggle]').forEach(header => {
  header.addEventListener('click', () => {
    const targetId = header.getAttribute('data-guide-toggle');
    const body = $(`#guide-${targetId}`);
    const icon = header.querySelector('.guide-toggle-icon');
    if (!body) return;
    const isOpen = body.classList.contains('open');
    // 다른건 닫지 않고 개별 토글
    body.classList.toggle('open');
    icon.textContent = isOpen ? '▼' : '▲';
  });
});

// 초기 로드
refreshFromCurrentTab();
checkServerAuth();
