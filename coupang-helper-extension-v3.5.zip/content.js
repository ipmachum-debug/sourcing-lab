/* ============================================================
   Coupang Sourcing Helper — Content Script v3.2
   쿠팡 검색결과 페이지에서 상품 데이터를 파싱하여 background로 전달
   
   v3.2: 쿠팡 HTML 구조 변경에 강건한 파싱 로직
   - 특정 class명 의존 제거, <a href="/vp/products/"> 기반 역추적
   - 가격/평점/리뷰를 정규식으로 텍스트에서 추출
   ============================================================ */
(function () {
  const MAX_ITEMS = 36;
  let debounceTimer = null;
  let lastSignature = '';

  function text(el) {
    return (el?.textContent || '').replace(/\s+/g, ' ').trim();
  }

  function getQuery() {
    const url = new URL(location.href);
    return url.searchParams.get('q') || url.searchParams.get('query') ||
      document.querySelector('input[type="search"]')?.value ||
      document.querySelector('input[name="q"]')?.value || '';
  }

  function parseNumber(str) {
    if (!str) return 0;
    return parseInt(str.replace(/[^0-9]/g, ''), 10) || 0;
  }

  function parseFloat2(str) {
    if (!str) return 0;
    const m = str.match(/[\d.]+/);
    return m ? parseFloat(m[0]) : 0;
  }

  // ---- Strategy 1: 기존 class 기반 파싱 (이전 쿠팡 구조) ----
  function parseProductsLegacy() {
    const products = [];
    const candidateSelectors = [
      'li.search-product',
      'li[class*="search-product"]',
      '[data-sentry-component="ProductUnit"]',
      'div[class*="search-product"]',
    ];

    const nodes = Array.from(document.querySelectorAll(candidateSelectors.join(',')));
    if (!nodes.length) return products;

    for (const node of nodes) {
      if (products.length >= MAX_ITEMS) break;

      const adBadge = node.querySelector('[class*="ad-badge"]') || node.querySelector('[class*="ad_badge"]');
      const isAd = !!adBadge || node.classList.contains('search-product__ad');

      const linkEl = node.querySelector('a[href*="/vp/products/"]') || node.querySelector('a.search-product-link');
      const titleEl = node.querySelector('.name') || node.querySelector('[class*="name"]') || linkEl;
      const priceEl = node.querySelector('.price-value') || node.querySelector('[class*="price"]');
      const ratingEl = node.querySelector('.rating') || node.querySelector('[class*="rating"]');
      const reviewEl = node.querySelector('.rating-total-count') || node.querySelector('[class*="review"]');
      const imageEl = node.querySelector('img');
      const rocketBadge = node.querySelector('[class*="rocket"]') || node.querySelector('img[alt*="로켓"]');

      const href = linkEl?.href || '';
      if (!href) continue;

      const productIdMatch = href.match(/\/vp\/products\/(\d+)/);
      const productId = productIdMatch ? productIdMatch[1] : null;

      const item = {
        productId,
        title: text(titleEl),
        price: parseNumber(text(priceEl)),
        priceText: text(priceEl),
        rating: parseFloat2(text(ratingEl)),
        ratingText: text(ratingEl),
        reviewCount: parseNumber(text(reviewEl).replace(/[()]/g, '')),
        reviewText: text(reviewEl),
        url: href,
        imageUrl: imageEl?.src || imageEl?.getAttribute('data-img-src') || '',
        position: products.length + 1,
        query: getQuery(),
        isAd,
        isRocket: !!rocketBadge
      };

      if (!item.title && !item.price) continue;
      products.push(item);
    }

    return products;
  }

  // ---- Strategy 2: <a> 링크 기반 역추적 파싱 (새 쿠팡 구조 대응) ----
  function parseProductsByLinks() {
    const products = [];
    const seenIds = new Set();

    // 모든 상품 링크를 찾음
    const allLinks = Array.from(document.querySelectorAll('a[href*="/vp/products/"]'));
    if (!allLinks.length) return products;

    for (const link of allLinks) {
      if (products.length >= MAX_ITEMS) break;

      const href = link.href || link.getAttribute('href') || '';
      const productIdMatch = href.match(/\/vp\/products\/(\d+)/);
      if (!productIdMatch) continue;

      const productId = productIdMatch[1];
      if (seenIds.has(productId)) continue;

      // 상위 컨테이너 찾기 (li, article, div 등 - 상품 카드 역할을 하는 부모)
      const container = findProductContainer(link);
      if (!container) continue;

      // 같은 컨테이너의 중복 체크
      seenIds.add(productId);

      const containerText = text(container);
      const containerHtml = container.innerHTML;

      // 제목 추출 (여러 전략)
      const title = extractTitle(container, link);
      if (!title) continue;

      // 가격 추출
      const price = extractPrice(container);

      // 평점 추출
      const rating = extractRating(container);

      // 리뷰 수 추출
      const reviewCount = extractReviewCount(container);

      // 이미지 추출
      const imageEl = container.querySelector('img[src*="thumbnail"], img[src*="image"], img[data-img-src]') || 
                       container.querySelector('img');
      const imageUrl = imageEl?.src || imageEl?.getAttribute('data-img-src') || '';

      // 광고 여부
      const isAd = detectAd(container, containerText);

      // 로켓배송 여부
      const isRocket = detectRocket(container, containerText);

      const item = {
        productId,
        title,
        price,
        priceText: price > 0 ? price.toLocaleString() + '원' : '',
        rating,
        ratingText: rating > 0 ? String(rating) : '',
        reviewCount,
        reviewText: reviewCount > 0 ? `(${reviewCount})` : '',
        url: href.startsWith('http') ? href : 'https://www.coupang.com' + href,
        imageUrl,
        position: products.length + 1,
        query: getQuery(),
        isAd,
        isRocket
      };

      products.push(item);
    }

    return products;
  }

  // 상품 컨테이너 찾기: 링크에서 위로 올라가며 적절한 부모 요소 탐색
  function findProductContainer(link) {
    let el = link.parentElement;
    let depth = 0;

    while (el && depth < 8) {
      // li, article, section 또는 특정 data-attribute가 있는 div
      const tag = el.tagName.toLowerCase();
      const cls = el.className || '';

      // 너무 큰 컨테이너(전체 리스트)에 도달하면 중단
      if (tag === 'ul' || tag === 'ol' || tag === 'main' || tag === 'body' || tag === 'section') {
        return el === link.parentElement ? null : el.querySelector(`a[href="${link.getAttribute('href')}"]`)?.closest('li, div, article') || link.parentElement;
      }

      // 상품 카드로 보이는 조건
      if (tag === 'li' && el.parentElement && (el.parentElement.tagName === 'UL' || el.parentElement.tagName === 'OL')) {
        return el;
      }

      if (tag === 'article') return el;

      // div이면서 상품 카드로 보이는 경우 (형제 중에 같은 구조가 3개 이상)
      if (tag === 'div' && el.parentElement) {
        const parent = el.parentElement;
        const siblings = parent.children;
        if (siblings.length >= 3) {
          // 형제들이 같은 태그인지 확인
          let sameTagCount = 0;
          for (const sib of siblings) {
            if (sib.tagName === el.tagName) sameTagCount++;
          }
          if (sameTagCount >= 3 && el.querySelector('a[href*="/vp/products/"]')) {
            return el;
          }
        }
      }

      // class에 product, item, card 등이 포함된 경우
      if (cls && /product|item|card|result|unit/i.test(cls) && depth >= 1) {
        return el;
      }

      // data attribute가 있는 경우
      if (el.dataset && (el.dataset.productId || el.dataset.itemId || el.dataset.vendorItemId)) {
        return el;
      }

      el = el.parentElement;
      depth++;
    }

    // 못 찾으면 링크의 상위 3단계 부모
    let fallback = link;
    for (let i = 0; i < 3 && fallback.parentElement; i++) {
      fallback = fallback.parentElement;
    }
    return fallback;
  }

  // 제목 추출
  function extractTitle(container, link) {
    // 1. class에 name, title이 포함된 요소
    const nameEl = container.querySelector('[class*="name"]') ||
                   container.querySelector('[class*="title"]') ||
                   container.querySelector('[class*="Name"]') ||
                   container.querySelector('[class*="Title"]');
    if (nameEl) {
      const t = text(nameEl);
      if (t.length > 5 && t.length < 500) return t;
    }

    // 2. 링크 텍스트 (긴 텍스트 포함된 링크)
    const linkText = text(link);
    if (linkText.length > 5 && linkText.length < 500) return linkText;

    // 3. 컨테이너 내 가장 긴 텍스트를 가진 a 태그
    const allAnchors = container.querySelectorAll('a');
    let longest = '';
    for (const a of allAnchors) {
      const t = text(a);
      if (t.length > longest.length && t.length < 500) longest = t;
    }
    if (longest.length > 5) return longest;

    // 4. 이미지 alt 텍스트
    const img = container.querySelector('img');
    if (img?.alt && img.alt.length > 3) return img.alt;

    return '';
  }

  // 가격 추출 (정규식 기반)
  function extractPrice(container) {
    // 1. class에 price가 포함된 요소에서 추출
    const priceEls = container.querySelectorAll('[class*="price"], [class*="Price"]');
    const prices = [];

    for (const el of priceEls) {
      const t = text(el);
      // "9,800원", "10,600원" 형태 매치
      const matches = t.match(/[\d,]+원/g);
      if (matches) {
        for (const m of matches) {
          const n = parseNumber(m);
          if (n >= 100 && n < 100000000) prices.push(n);
        }
      }
    }

    // 가장 낮은 가격 반환 (할인가가 보통 낮음)
    if (prices.length) return Math.min(...prices);

    // 2. 컨테이너 전체 텍스트에서 가격 패턴 추출
    const fullText = text(container);
    const priceMatches = fullText.match(/[\d,]+원/g);
    if (priceMatches) {
      const nums = priceMatches.map(m => parseNumber(m)).filter(n => n >= 100 && n < 100000000);
      if (nums.length) return Math.min(...nums);
    }

    return 0;
  }

  // 평점 추출
  function extractRating(container) {
    // 1. class에 rating, star 포함된 요소
    const ratingEl = container.querySelector('[class*="rating"]') ||
                     container.querySelector('[class*="star"]') ||
                     container.querySelector('[class*="Rating"]') ||
                     container.querySelector('[class*="Star"]');
    if (ratingEl) {
      const t = text(ratingEl);
      const m = t.match(/(\d+\.?\d*)/);
      if (m) {
        const val = parseFloat(m[1]);
        if (val > 0 && val <= 5) return val;
      }
    }

    // 2. aria-label에서 추출
    const starEl = container.querySelector('[aria-label*="별점"], [aria-label*="star"]');
    if (starEl) {
      const label = starEl.getAttribute('aria-label') || '';
      const m = label.match(/(\d+\.?\d*)/);
      if (m) {
        const val = parseFloat(m[1]);
        if (val > 0 && val <= 5) return val;
      }
    }

    return 0;
  }

  // 리뷰 수 추출
  function extractReviewCount(container) {
    // 1. class에 review, count 포함된 요소
    const reviewEl = container.querySelector('[class*="review"]') ||
                     container.querySelector('[class*="Review"]') ||
                     container.querySelector('[class*="count"]') ||
                     container.querySelector('.rating-total-count');
    if (reviewEl) {
      const t = text(reviewEl).replace(/[()]/g, '');
      const n = parseNumber(t);
      if (n > 0 && n < 10000000) return n;
    }

    // 2. 괄호 안의 숫자 패턴 (123), (1,234) 등
    const fullText = text(container);
    const parenMatch = fullText.match(/\((\d[\d,]*)\)/g);
    if (parenMatch) {
      for (const m of parenMatch) {
        const n = parseNumber(m);
        if (n > 0 && n < 10000000) return n;
      }
    }

    return 0;
  }

  // 광고 여부 감지
  function detectAd(container, containerText) {
    // class 기반
    const cls = (container.className || '') + ' ' + container.innerHTML;
    if (/ad[-_]?badge|광고|ad_label|sponsored/i.test(cls)) return true;

    // 텍스트 기반 - "광고" 또는 "AD" 가 직접적으로 있는 경우
    const adEl = container.querySelector('[class*="ad"]');
    if (adEl && /^AD$/i.test(text(adEl).trim())) return true;

    // 컨테이너 내 작은 텍스트 요소에서 "AD" 찾기
    const smallEls = container.querySelectorAll('span, em, strong, div, p');
    for (const el of smallEls) {
      const t = text(el).trim();
      if (t === 'AD' || t === 'ad' || t === '광고') return true;
    }

    return false;
  }

  // 로켓배송 감지
  function detectRocket(container, containerText) {
    if (container.querySelector('[class*="rocket"]')) return true;
    if (container.querySelector('img[alt*="로켓"]')) return true;
    if (container.querySelector('img[src*="rocket"]')) return true;
    if (/로켓배송|로켓와우|로켓프레시|로켓직구/i.test(containerText)) return true;
    return false;
  }

  // ---- 통합 파싱 ----
  function parseProducts() {
    // Strategy 1: 기존 class 기반 (빠르고 정확)
    let products = parseProductsLegacy();
    if (products.length >= 3) {
      return products;
    }

    // Strategy 2: 링크 기반 역추적 (더 강건)
    products = parseProductsByLinks();
    return products;
  }

  function publishResults() {
    const items = parseProducts();
    const query = getQuery();
    const signature = JSON.stringify({ query, count: items.length, ids: items.map(i => i.productId || i.url).slice(0, 5) });

    if (signature === lastSignature) return;
    lastSignature = signature;

    chrome.runtime.sendMessage({
      type: 'SEARCH_RESULTS_PARSED',
      query,
      items
    }).catch(() => {});
  }

  function schedulePublish() {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(publishResults, 800);
  }

  // MutationObserver로 DOM 변경 감지 (SPA 대응)
  const observer = new MutationObserver(() => schedulePublish());
  observer.observe(document.documentElement, {
    childList: true,
    subtree: true
  });

  // 여러 시점에서 파싱 시도
  window.addEventListener('load', schedulePublish);
  document.addEventListener('visibilitychange', schedulePublish);
  
  // 초기 로드 시 여러 번 시도 (렌더링 지연 대응)
  schedulePublish();
  setTimeout(schedulePublish, 1500);
  setTimeout(schedulePublish, 3000);
  setTimeout(schedulePublish, 5000);
})();
