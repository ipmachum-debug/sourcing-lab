/* ============================================================
   Coupang Sourcing Helper — Background Service Worker
   세션 스토리지 관리 + 검색 히스토리 저장 + 서버 동기화
   ============================================================ */

importScripts('api-client.js');

chrome.runtime.onInstalled.addListener(() => {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // 검색 결과 파싱 완료
  if (message?.type === 'SEARCH_RESULTS_PARSED' && sender.tab?.id) {
    const tabId = sender.tab.id;
    const payload = {
      tabId,
      url: sender.tab.url,
      title: sender.tab.title,
      query: message.query || '',
      count: Array.isArray(message.items) ? message.items.length : 0,
      items: message.items || [],
      capturedAt: new Date().toISOString()
    };

    chrome.storage.session.set({ [`results:${tabId}`]: payload });

    // 로컬 히스토리 저장
    saveSearchHistory(payload);

    // 서버에 스냅샷 동기화 (비동기, 실패해도 무시)
    syncSnapshotToServer(payload).catch(() => {});

    chrome.runtime.sendMessage({ type: 'RESULTS_UPDATED', tabId }).catch(() => {});
    sendResponse({ ok: true });
    return true;
  }

  // 특정 탭 결과 조회
  if (message?.type === 'GET_RESULTS_FOR_TAB') {
    const key = `results:${message.tabId}`;
    chrome.storage.session.get([key]).then((obj) => {
      sendResponse({ ok: true, data: obj[key] || null });
    });
    return true;
  }

  // 후보 저장
  if (message?.type === 'SAVE_CANDIDATE') {
    saveCandidateItem(message.item).then((result) => {
      sendResponse({ ok: true, ...result });
    });
    return true;
  }

  // 후보 삭제
  if (message?.type === 'REMOVE_CANDIDATE') {
    removeCandidateItem(message.productId).then(() => {
      sendResponse({ ok: true });
    });
    return true;
  }

  // 후보 목록 조회
  if (message?.type === 'GET_CANDIDATES') {
    getCandidates().then((candidates) => {
      sendResponse({ ok: true, data: candidates });
    });
    return true;
  }

  // 히스토리 조회
  if (message?.type === 'GET_HISTORY') {
    getSearchHistory().then((history) => {
      sendResponse({ ok: true, data: history });
    });
    return true;
  }

  // 히스토리 삭제
  if (message?.type === 'CLEAR_HISTORY') {
    chrome.storage.local.set({ searchHistory: [] }).then(() => {
      sendResponse({ ok: true });
    });
    return true;
  }

  // ---- 서버 연동 메시지 ----

  // 서버 로그인
  if (message?.type === 'SERVER_LOGIN') {
    apiClient.login(message.email, message.password).then((result) => {
      sendResponse({ ok: true, ...result });
    }).catch(e => {
      sendResponse({ ok: false, error: e.message });
    });
    return true;
  }

  // 서버 인증 상태 확인
  if (message?.type === 'SERVER_CHECK_AUTH') {
    apiClient.checkAuth().then((result) => {
      sendResponse({ ok: true, ...result });
    }).catch(e => {
      sendResponse({ ok: false, error: e.message });
    });
    return true;
  }

  // 서버 검색 통계
  if (message?.type === 'SERVER_SEARCH_STATS') {
    apiClient.searchStats().then((resp) => {
      sendResponse({ ok: true, data: resp?.result?.data });
    }).catch(e => {
      sendResponse({ ok: false, error: e.message });
    });
    return true;
  }

  // 서버 후보 통계
  if (message?.type === 'SERVER_CANDIDATE_STATS') {
    apiClient.candidateStats().then((resp) => {
      sendResponse({ ok: true, data: resp?.result?.data });
    }).catch(e => {
      sendResponse({ ok: false, error: e.message });
    });
    return true;
  }

  // 서버 후보 목록
  if (message?.type === 'SERVER_LIST_CANDIDATES') {
    apiClient.listCandidates(message.opts || {}).then((resp) => {
      sendResponse({ ok: true, data: resp?.result?.data });
    }).catch(e => {
      sendResponse({ ok: false, error: e.message });
    });
    return true;
  }

  // 서버 검색 히스토리
  if (message?.type === 'SERVER_LIST_SNAPSHOTS') {
    apiClient.listSnapshots(message.opts || {}).then((resp) => {
      sendResponse({ ok: true, data: resp?.result?.data });
    }).catch(e => {
      sendResponse({ ok: false, error: e.message });
    });
    return true;
  }

  // 후보를 소싱 상품으로 승격
  if (message?.type === 'SERVER_PROMOTE_CANDIDATE') {
    apiClient.promoteToProduct(message.candidateId).then((resp) => {
      sendResponse({ ok: true, data: resp?.result?.data });
    }).catch(e => {
      sendResponse({ ok: false, error: e.message });
    });
    return true;
  }
});

// ---- 서버 동기화 ----
async function syncSnapshotToServer(payload) {
  const { serverLoggedIn } = await chrome.storage.local.get('serverLoggedIn');
  if (!serverLoggedIn) return;

  const items = payload.items || [];
  const prices = items.map(i => i.price).filter(p => p > 0);
  const ratings = items.map(i => i.rating).filter(r => r > 0);
  const reviews = items.map(i => i.reviewCount).filter(r => r > 0);

  const avgPrice = prices.length ? Math.round(prices.reduce((a, b) => a + b, 0) / prices.length) : 0;
  const avgRating = ratings.length ? +(ratings.reduce((a, b) => a + b, 0) / ratings.length).toFixed(1) : 0;
  const avgReview = reviews.length ? Math.round(reviews.reduce((a, b) => a + b, 0) / reviews.length) : 0;
  const highReviewCount = items.filter(i => i.reviewCount >= 100).length;
  const highReviewRatio = items.length ? Math.round((highReviewCount / items.length) * 100) : 0;
  const adCount = items.filter(i => i.isAd).length;

  // 경쟁 점수 계산
  let competitionScore = 0;
  if (avgReview > 1000) competitionScore += 40;
  else if (avgReview > 500) competitionScore += 30;
  else if (avgReview > 100) competitionScore += 20;
  else if (avgReview > 30) competitionScore += 10;
  if (highReviewRatio > 60) competitionScore += 25;
  else if (highReviewRatio > 40) competitionScore += 15;
  else if (highReviewRatio > 20) competitionScore += 8;
  if (avgRating >= 4.5) competitionScore += 15;
  else if (avgRating >= 4.0) competitionScore += 8;
  const adRatio = items.length ? adCount / items.length : 0;
  if (adRatio > 0.3) competitionScore += 20;
  else if (adRatio > 0.15) competitionScore += 10;

  const competitionLevel = competitionScore >= 70 ? 'hard' : competitionScore >= 45 ? 'medium' : 'easy';

  await apiClient.saveSnapshot({
    query: payload.query,
    totalItems: payload.count,
    avgPrice,
    avgRating,
    avgReview,
    highReviewRatio,
    adCount,
    competitionScore,
    competitionLevel,
    items: items.slice(0, 20), // 상위 20개만 저장
  });
}

async function syncCandidateToServer(item) {
  const { serverLoggedIn } = await chrome.storage.local.get('serverLoggedIn');
  if (!serverLoggedIn) return null;

  try {
    const resp = await apiClient.saveCandidate({
      productId: item.productId || undefined,
      title: item.title || undefined,
      price: item.price || 0,
      rating: item.rating || 0,
      reviewCount: item.reviewCount || 0,
      imageUrl: item.imageUrl || undefined,
      coupangUrl: item.url || undefined,
      sourcingScore: item._sourcingScore || 0,
      sourcingGrade: item._sourcingGrade || undefined,
      searchQuery: item.query || undefined,
    });
    return resp?.result?.data;
  } catch (e) {
    return null;
  }
}

// ---- 검색 히스토리 (로컬) ----
async function saveSearchHistory(payload) {
  const { searchHistory = [] } = await chrome.storage.local.get('searchHistory');
  const entry = {
    query: payload.query,
    count: payload.count,
    avgPrice: calcAvg(payload.items.map(i => i.price).filter(p => p > 0)),
    avgRating: calcAvg(payload.items.map(i => i.rating).filter(r => r > 0)),
    avgReview: calcAvg(payload.items.map(i => i.reviewCount).filter(r => r > 0)),
    timestamp: payload.capturedAt
  };
  const idx = searchHistory.findIndex(h => h.query === entry.query);
  if (idx >= 0) searchHistory.splice(idx, 1);
  searchHistory.unshift(entry);
  if (searchHistory.length > 100) searchHistory.length = 100;
  await chrome.storage.local.set({ searchHistory });
}

async function getSearchHistory() {
  const { searchHistory = [] } = await chrome.storage.local.get('searchHistory');
  return searchHistory;
}

// ---- 후보 저장 (로컬 + 서버) ----
async function saveCandidateItem(item) {
  const { candidates = [] } = await chrome.storage.local.get('candidates');
  if (candidates.find(c => c.productId === item.productId)) {
    return { alreadySaved: true };
  }
  item.savedAt = new Date().toISOString();
  candidates.unshift(item);
  if (candidates.length > 500) candidates.length = 500;
  await chrome.storage.local.set({ candidates });

  // 서버에도 동기화
  const serverResult = await syncCandidateToServer(item);
  return { alreadySaved: false, serverId: serverResult?.id };
}

async function removeCandidateItem(productId) {
  const { candidates = [] } = await chrome.storage.local.get('candidates');
  const filtered = candidates.filter(c => c.productId !== productId);
  await chrome.storage.local.set({ candidates: filtered });
}

async function getCandidates() {
  const { candidates = [] } = await chrome.storage.local.get('candidates');
  return candidates;
}

function calcAvg(arr) {
  if (!arr.length) return 0;
  return Math.round(arr.reduce((a, b) => a + b, 0) / arr.length);
}
