/* ============================================================
   Coupang Sourcing Helper — Side Panel Logic
   분석 · 경쟁도 · 1688 연동 · 후보 저장 · 히스토리 · 마진 계산
   ============================================================ */

// ---- State ----
let currentData = null;
let currentItems = [];

// ---- DOM refs ----
const $ = (s) => document.querySelector(s);
const $$ = (s) => document.querySelectorAll(s);

// ---- Tab 관리 ----
$$('.tab').forEach(btn => {
  btn.addEventListener('click', () => {
    $$('.tab').forEach(t => t.classList.remove('active'));
    $$('.tab-content').forEach(c => c.classList.remove('active'));
    btn.classList.add('active');
    $(`#tab-${btn.dataset.tab}`).classList.add('active');

    // 탭 전환 시 데이터 로드
    if (btn.dataset.tab === 'candidates') loadCandidates();
    if (btn.dataset.tab === 'history') loadHistory();
  });
});

// ============================================================
//  분석 탭
// ============================================================

async function getActiveTab() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  return tabs[0] || null;
}

async function getResults(tabId) {
  return chrome.runtime.sendMessage({ type: 'GET_RESULTS_FOR_TAB', tabId });
}

function formatPrice(n) {
  if (!n) return '-';
  return n.toLocaleString('ko-KR') + '원';
}

// ---- 소싱 점수 계산 ----
// 리뷰 적고, 평점 낮고, 가격 높은 상품 = 소싱 기회
function calcSourcingScore(item, avgPrice, avgReview) {
  let score = 50; // 기본

  // 리뷰가 적으면 +점수 (진입 장벽 낮음)
  if (item.reviewCount === 0) score += 25;
  else if (item.reviewCount < 10) score += 20;
  else if (item.reviewCount < 50) score += 10;
  else if (item.reviewCount < 100) score += 5;
  else if (item.reviewCount > 500) score -= 15;
  else if (item.reviewCount > 1000) score -= 25;

  // 평점이 낮으면 +점수 (개선 여지)
  if (item.rating > 0 && item.rating < 3.5) score += 10;
  else if (item.rating >= 4.5) score -= 5;

  // 가격이 평균보다 높으면 +점수 (마진 여유)
  if (avgPrice > 0 && item.price > 0) {
    const priceRatio = item.price / avgPrice;
    if (priceRatio > 1.3) score += 15;
    else if (priceRatio > 1.1) score += 8;
    else if (priceRatio < 0.7) score -= 10;
  }

  // 광고 상품이면 -점수 (이미 경쟁중)
  if (item.isAd) score -= 10;

  // 로켓배송이면 -점수 (쿠팡 직접 판매)
  if (item.isRocket) score -= 5;

  return Math.max(0, Math.min(100, score));
}

function getSourcingGrade(score) {
  if (score >= 80) return { grade: 'A', label: '매우 좋음', cls: 'grade-a' };
  if (score >= 65) return { grade: 'B', label: '좋음', cls: 'grade-b' };
  if (score >= 50) return { grade: 'C', label: '보통', cls: 'grade-c' };
  if (score >= 35) return { grade: 'D', label: '어려움', cls: 'grade-d' };
  return { grade: 'F', label: '매우 어려움', cls: 'grade-f' };
}

// ---- 경쟁 강도 분석 ----
function analyzeCompetition(items) {
  if (!items.length) return null;

  const prices = items.map(i => i.price).filter(p => p > 0);
  const reviews = items.map(i => i.reviewCount).filter(r => r > 0);
  const ratings = items.map(i => i.rating).filter(r => r > 0);

  const avgPrice = prices.length ? Math.round(prices.reduce((a, b) => a + b, 0) / prices.length) : 0;
  const avgReview = reviews.length ? Math.round(reviews.reduce((a, b) => a + b, 0) / reviews.length) : 0;
  const avgRating = ratings.length ? (ratings.reduce((a, b) => a + b, 0) / ratings.length).toFixed(1) : 0;
  const highReviewCount = items.filter(i => i.reviewCount >= 100).length;
  const highReviewRatio = Math.round((highReviewCount / items.length) * 100);
  const adCount = items.filter(i => i.isAd).length;

  // 경쟁 강도 점수 (0~100, 높을수록 경쟁 치열)
  let competitionScore = 0;

  // 평균 리뷰 수 기반 (가장 큰 지표)
  if (avgReview > 1000) competitionScore += 40;
  else if (avgReview > 500) competitionScore += 30;
  else if (avgReview > 100) competitionScore += 20;
  else if (avgReview > 30) competitionScore += 10;

  // 리뷰 100+ 비율
  if (highReviewRatio > 60) competitionScore += 25;
  else if (highReviewRatio > 40) competitionScore += 15;
  else if (highReviewRatio > 20) competitionScore += 8;

  // 평균 평점 (높으면 이미 좋은 상품 많음)
  if (avgRating >= 4.5) competitionScore += 15;
  else if (avgRating >= 4.0) competitionScore += 8;

  // 광고 비율
  const adRatio = adCount / items.length;
  if (adRatio > 0.3) competitionScore += 20;
  else if (adRatio > 0.15) competitionScore += 10;

  let level, levelText, levelCls;
  if (competitionScore >= 70) { level = '강함'; levelText = '경쟁이 매우 치열합니다. 차별화 전략이 필요합니다.'; levelCls = 'level-hard'; }
  else if (competitionScore >= 45) { level = '보통'; levelText = '경쟁이 있지만 진입 가능합니다.'; levelCls = 'level-medium'; }
  else { level = '약함'; levelText = '경쟁이 낮습니다. 소싱 기회!'; levelCls = 'level-easy'; }

  return {
    competitionScore,
    level, levelText, levelCls,
    avgPrice, avgReview, avgRating, highReviewRatio, adCount,
    totalItems: items.length
  };
}

// ---- 상품 목록 렌더 ----
function renderItems(items, comp) {
  const results = $('#results');
  const tpl = $('#itemTemplate');
  results.innerHTML = '';

  if (!items.length) {
    results.innerHTML = '<li class="empty-msg">표시할 상품이 없습니다.</li>';
    return;
  }

  const avgPrice = comp?.avgPrice || 0;
  const avgReview = comp?.avgReview || 0;

  for (const item of items) {
    const node = tpl.content.cloneNode(true);
    const li = node.querySelector('li');

    // 이미지
    const img = node.querySelector('.item-img');
    if (item.imageUrl) {
      img.src = item.imageUrl;
      img.alt = item.title;
    } else {
      img.style.display = 'none';
    }

    // 배지
    const badges = node.querySelector('.item-badges');
    let badgeHtml = `<span class="badge-rank">#${item.position}</span>`;
    if (item.isAd) badgeHtml += '<span class="badge-ad">AD</span>';
    if (item.isRocket) badgeHtml += '<span class="badge-rocket">🚀</span>';
    badges.innerHTML = badgeHtml;

    // 제목
    node.querySelector('.title').textContent = item.title || '(제목 없음)';

    // 가격
    node.querySelector('.price-line').textContent = item.price ? formatPrice(item.price) : '-';

    // 메타
    node.querySelector('.meta-line').textContent =
      `평점 ${item.rating || '-'} · 리뷰 ${item.reviewCount?.toLocaleString() || '0'}개`;

    // 소싱 점수
    const sourcingScore = calcSourcingScore(item, avgPrice, avgReview);
    item._sourcingScore = sourcingScore;
    const grade = getSourcingGrade(sourcingScore);
    const scoreEl = node.querySelector('.score-value');
    scoreEl.textContent = `${grade.grade} (${sourcingScore}점)`;
    scoreEl.className = `score-value ${grade.cls}`;

    // 1688 찾기 버튼
    node.querySelector('.btn-1688').addEventListener('click', () => {
      const keyword = extractKeyword(item.title);
      const url = `https://s.1688.com/selloffer/offer_search.htm?keywords=${encodeURIComponent(keyword)}`;
      chrome.tabs.create({ url });
    });

    // 저장 버튼
    const saveBtn = node.querySelector('.btn-save');
    saveBtn.addEventListener('click', async () => {
      await chrome.runtime.sendMessage({ type: 'SAVE_CANDIDATE', item });
      saveBtn.textContent = '✅ 저장됨';
      saveBtn.disabled = true;
    });

    // 상품 링크
    node.querySelector('.btn-link').href = item.url;

    results.appendChild(node);
  }
}

// 제목에서 핵심 키워드 추출 (1688 검색용)
function extractKeyword(title) {
  if (!title) return '';
  // 브랜드명, 특수문자 제거 → 핵심 명사만
  let cleaned = title
    .replace(/\[.*?\]/g, '')
    .replace(/\(.*?\)/g, '')
    .replace(/[^\uAC00-\uD7A3a-zA-Z0-9\s]/g, '')
    .trim();
  // 너무 길면 앞 4단어만
  const words = cleaned.split(/\s+/).filter(w => w.length > 1);
  return words.slice(0, 4).join(' ');
}

// ---- 필터 & 정렬 ----
function getFilteredSorted() {
  if (!currentData?.items) return [];
  let items = [...currentData.items];

  // 광고 제외
  if ($('#filterNoAd').checked) {
    items = items.filter(i => !i.isAd);
  }

  // 소싱 쉬운것만 (점수 60+)
  if ($('#filterEasySourcing').checked) {
    const comp = analyzeCompetition(currentData.items);
    items.forEach(i => {
      i._sourcingScore = calcSourcingScore(i, comp?.avgPrice || 0, comp?.avgReview || 0);
    });
    items = items.filter(i => i._sourcingScore >= 60);
  }

  // 상위 N개
  const topN = parseInt($('#topNSelect').value) || 0;
  if (topN > 0) items = items.slice(0, topN);

  // 정렬
  const sort = $('#sortSelect').value;
  switch (sort) {
    case 'price-asc': items.sort((a, b) => (a.price || 0) - (b.price || 0)); break;
    case 'price-desc': items.sort((a, b) => (b.price || 0) - (a.price || 0)); break;
    case 'review-desc': items.sort((a, b) => (b.reviewCount || 0) - (a.reviewCount || 0)); break;
    case 'rating-desc': items.sort((a, b) => (b.rating || 0) - (a.rating || 0)); break;
    case 'sourcing-desc': {
      const comp = analyzeCompetition(currentData.items);
      items.forEach(i => {
        i._sourcingScore = calcSourcingScore(i, comp?.avgPrice || 0, comp?.avgReview || 0);
      });
      items.sort((a, b) => (b._sourcingScore || 0) - (a._sourcingScore || 0));
      break;
    }
    default: break; // position 유지
  }

  return items;
}

function renderAnalysis(data) {
  currentData = data;

  if (!data || !data.items?.length) {
    $('#summary').textContent = '쿠팡 검색 결과 페이지를 열면 자동 분석됩니다.';
    $('#competitionCard').style.display = 'none';
    $('#statsGrid').style.display = 'none';
    $('#filterBar').style.display = 'none';
    $('#results').innerHTML = '';
    return;
  }

  // 요약
  $('#summary').textContent = `"${data.query || '-'}" · ${data.count}개 감지 · ${new Date(data.capturedAt).toLocaleTimeString('ko-KR')}`;

  // 경쟁도 분석
  const comp = analyzeCompetition(data.items);
  if (comp) {
    $('#competitionCard').style.display = '';
    $('#competitionBadge').textContent = `${comp.level} (${comp.competitionScore}점)`;
    $('#competitionBadge').className = `competition-badge ${comp.levelCls}`;
    $('#competitionDetails').innerHTML = `
      <div>${comp.levelText}</div>
      <div class="comp-stats">
        상품 ${comp.totalItems}개 · 광고 ${comp.adCount}개 · 리뷰100+ ${comp.highReviewRatio}%
      </div>
    `;

    // 통계
    $('#statsGrid').style.display = '';
    $('#statAvgPrice').textContent = formatPrice(comp.avgPrice);
    $('#statAvgRating').textContent = comp.avgRating || '-';
    $('#statAvgReview').textContent = comp.avgReview?.toLocaleString() || '-';
    $('#statHighReviewRatio').textContent = comp.highReviewRatio + '%';
  }

  // 필터바 표시
  $('#filterBar').style.display = '';

  // 상품 렌더
  const filtered = getFilteredSorted();
  renderItems(filtered, comp);
}

// 필터/정렬 이벤트
$('#sortSelect').addEventListener('change', () => renderAnalysis(currentData));
$('#filterNoAd').addEventListener('change', () => renderAnalysis(currentData));
$('#filterEasySourcing').addEventListener('change', () => renderAnalysis(currentData));
$('#topNSelect').addEventListener('change', () => renderAnalysis(currentData));

// ============================================================
//  후보 탭
// ============================================================

async function loadCandidates() {
  const resp = await chrome.runtime.sendMessage({ type: 'GET_CANDIDATES' });
  const candidates = resp?.data || [];
  const list = $('#candidateList');
  const tpl = $('#candidateTemplate');
  const empty = $('#candidateEmpty');
  const count = $('#candidateCount');

  list.innerHTML = '';
  count.textContent = candidates.length;

  if (!candidates.length) {
    empty.style.display = '';
    return;
  }
  empty.style.display = 'none';

  for (const item of candidates) {
    const node = tpl.content.cloneNode(true);

    const img = node.querySelector('.item-img');
    if (item.imageUrl) { img.src = item.imageUrl; img.alt = item.title; }
    else img.style.display = 'none';

    node.querySelector('.title').textContent = item.title;
    node.querySelector('.price-line').textContent = item.price ? formatPrice(item.price) : '-';
    node.querySelector('.meta-line').textContent =
      `평점 ${item.rating || '-'} · 리뷰 ${item.reviewCount?.toLocaleString() || '0'}개 · 저장: ${new Date(item.savedAt).toLocaleDateString('ko-KR')}`;

    node.querySelector('.btn-1688').addEventListener('click', () => {
      const keyword = extractKeyword(item.title);
      chrome.tabs.create({ url: `https://s.1688.com/selloffer/offer_search.htm?keywords=${encodeURIComponent(keyword)}` });
    });

    node.querySelector('.btn-remove').addEventListener('click', async () => {
      await chrome.runtime.sendMessage({ type: 'REMOVE_CANDIDATE', productId: item.productId });
      loadCandidates();
    });

    node.querySelector('.btn-link').href = item.url;

    list.appendChild(node);
  }
}

// ============================================================
//  히스토리 탭
// ============================================================

async function loadHistory() {
  const resp = await chrome.runtime.sendMessage({ type: 'GET_HISTORY' });
  const history = resp?.data || [];
  const list = $('#historyList');
  const empty = $('#historyEmpty');

  list.innerHTML = '';
  if (!history.length) { empty.style.display = ''; return; }
  empty.style.display = 'none';

  for (const h of history) {
    const li = document.createElement('li');
    li.className = 'history-item';
    li.innerHTML = `
      <div class="history-query">"${h.query}"</div>
      <div class="history-stats">
        ${h.count}개 · 평균가 ${formatPrice(h.avgPrice)} · 평점 ${h.avgRating || '-'} · 리뷰 ${h.avgReview || '-'}
      </div>
      <div class="history-time">${new Date(h.timestamp).toLocaleString('ko-KR')}</div>
    `;
    // 클릭하면 검색
    li.addEventListener('click', () => {
      chrome.tabs.create({ url: `https://www.coupang.com/np/search?q=${encodeURIComponent(h.query)}` });
    });
    list.appendChild(li);
  }
}

$('#clearHistoryBtn').addEventListener('click', async () => {
  if (!confirm('검색 히스토리를 모두 삭제할까요?')) return;
  await chrome.runtime.sendMessage({ type: 'CLEAR_HISTORY' });
  loadHistory();
});

// ============================================================
//  마진 계산기
// ============================================================

$('#calcBtn').addEventListener('click', () => {
  const cnyCost = parseFloat($('#calcCnyCost').value) || 0;
  const exchangeRate = parseFloat($('#calcExchangeRate').value) || 190;
  const shipping = parseFloat($('#calcShipping').value) || 0;
  const taxRate = parseFloat($('#calcTaxRate').value) || 0;
  const salePrice = parseFloat($('#calcSalePrice').value) || 0;
  const commissionRate = parseFloat($('#calcCommission').value) || 0;

  const costKrw = Math.round(cnyCost * exchangeRate);
  const tax = Math.round(costKrw * (taxRate / 100));
  const totalCost = costKrw + shipping + tax;
  const commission = Math.round(salePrice * (commissionRate / 100));
  const profit = salePrice - totalCost - commission;
  const margin = salePrice > 0 ? ((profit / salePrice) * 100).toFixed(1) : 0;

  $('#calcResult').style.display = '';
  $('#resultCostKrw').textContent = formatPrice(costKrw);
  $('#resultShipping').textContent = formatPrice(shipping);
  $('#resultTax').textContent = formatPrice(tax);
  $('#resultTotalCost').textContent = formatPrice(totalCost);
  $('#resultCommission').textContent = formatPrice(commission);
  $('#resultProfit').textContent = formatPrice(profit);
  $('#resultMargin').textContent = margin + '%';

  const profitRow = $('#profitRow');
  const marginRow = $('#marginRow');
  if (profit > 0) {
    profitRow.className = 'calc-result-row profit-row profit-positive';
    marginRow.className = 'calc-result-row margin-row profit-positive';
  } else {
    profitRow.className = 'calc-result-row profit-row profit-negative';
    marginRow.className = 'calc-result-row margin-row profit-negative';
  }
});

// ============================================================
//  서버 연동 탭
// ============================================================

const statusLabels = {
  new: '신규',
  reviewing: '검토중',
  contacted_supplier: '공급처 연락',
  sample_ordered: '샘플 주문',
  dropped: '탈락',
  selected: '선정',
};

async function checkServerAuth() {
  try {
    const resp = await chrome.runtime.sendMessage({ type: 'SERVER_CHECK_AUTH' });
    if (resp?.ok && resp.loggedIn) {
      showLoggedIn(resp.user);
      return true;
    }
    showLoginForm();
    return false;
  } catch (e) {
    showLoginForm();
    return false;
  }
}

function showLoggedIn(user) {
  const syncDot = $('#syncStatus');
  syncDot.className = 'sync-status sync-connected';
  syncDot.title = '서버 연결됨';
  $('#serverLoginForm').style.display = 'none';
  $('#serverLoggedIn').style.display = '';
  $('#serverUserName').textContent = user?.name || '사용자';
  $('#serverUserEmail').textContent = user?.email || '';
  $('#serverStatusBadge').textContent = '연결됨';
  $('#serverStatusBadge').className = 'sync-indicator sync-connected';
  loadServerStats();
}

function showLoginForm() {
  const syncDot = $('#syncStatus');
  syncDot.className = 'sync-status sync-disconnected';
  syncDot.title = '서버 미연결';
  $('#serverLoginForm').style.display = '';
  $('#serverLoggedIn').style.display = 'none';
  $('#serverStatusBadge').textContent = '미연결';
  $('#serverStatusBadge').className = 'sync-indicator sync-disconnected';
  $('#serverStatsCard').style.display = 'none';
}

$('#serverLoginBtn').addEventListener('click', async () => {
  const email = $('#serverEmail').value.trim();
  const password = $('#serverPassword').value;
  const errorEl = $('#serverLoginError');
  errorEl.style.display = 'none';

  if (!email || !password) {
    errorEl.textContent = '이메일과 비밀번호를 입력하세요.';
    errorEl.style.display = '';
    return;
  }

  const btn = $('#serverLoginBtn');
  btn.disabled = true;
  btn.textContent = '로그인 중...';

  try {
    const resp = await chrome.runtime.sendMessage({
      type: 'SERVER_LOGIN',
      email,
      password
    });
    if (resp?.ok) {
      showLoggedIn(resp.user);
    } else {
      errorEl.textContent = resp?.error || '로그인 실패';
      errorEl.style.display = '';
    }
  } catch (e) {
    errorEl.textContent = e.message || '로그인 실패';
    errorEl.style.display = '';
  } finally {
    btn.disabled = false;
    btn.textContent = '로그인';
  }
});

$('#serverLogoutBtn').addEventListener('click', async () => {
  await chrome.storage.local.set({ serverLoggedIn: false, serverEmail: '' });
  showLoginForm();
});

async function loadServerStats() {
  const statsCard = $('#serverStatsCard');
  try {
    // 검색 통계
    const searchResp = await chrome.runtime.sendMessage({ type: 'SERVER_SEARCH_STATS' });
    const searchData = searchResp?.data;

    // 후보 통계
    const candResp = await chrome.runtime.sendMessage({ type: 'SERVER_CANDIDATE_STATS' });
    const candData = candResp?.data;

    if (!searchData && !candData) {
      statsCard.style.display = 'none';
      return;
    }

    statsCard.style.display = '';

    // 기본 통계
    $('#srvTotalSearches').textContent = searchData?.totalSearches || 0;
    $('#srvUniqueQueries').textContent = searchData?.uniqueQueries || 0;
    $('#srvTotalCandidates').textContent = candData?.total || 0;
    $('#srvAvgScore').textContent = candData?.avgScore || '-';

    // TOP 검색어
    const topList = $('#srvTopQueries');
    topList.innerHTML = '';
    if (searchData?.topQueries?.length) {
      for (const q of searchData.topQueries) {
        const li = document.createElement('li');
        li.className = 'top-query-item';
        li.innerHTML = `
          <span class="tq-query">"${q.query}"</span>
          <span class="tq-count">${q.count}회</span>
          <span class="tq-comp">경쟁 ${q.avgCompetition || '-'}점</span>
        `;
        li.addEventListener('click', () => {
          chrome.tabs.create({ url: `https://www.coupang.com/np/search?q=${encodeURIComponent(q.query)}` });
        });
        topList.appendChild(li);
      }
    } else {
      topList.innerHTML = '<li class="empty-msg">아직 검색 기록이 없습니다.</li>';
    }

    // 후보 상태별 현황
    const statusDiv = $('#srvStatusCounts');
    statusDiv.innerHTML = '';
    if (candData?.statusCounts?.length) {
      for (const s of candData.statusCounts) {
        const chip = document.createElement('span');
        chip.className = `status-chip status-${s.status}`;
        chip.textContent = `${statusLabels[s.status] || s.status} ${s.count}`;
        statusDiv.appendChild(chip);
      }
    } else {
      statusDiv.innerHTML = '<span class="empty-msg">후보 없음</span>';
    }
  } catch (e) {
    statsCard.style.display = 'none';
  }
}

// ============================================================
//  데이터 로드 & 실시간 업데이트
// ============================================================

async function refreshFromCurrentTab() {
  const tab = await getActiveTab();
  if (!tab?.id) return;

  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => { document.dispatchEvent(new Event('visibilitychange')); }
    });
  } catch (e) { /* 쿠팡 외 페이지 */ }

  const response = await getResults(tab.id);
  renderAnalysis(response?.data || null);
}

chrome.runtime.onMessage.addListener(async (message) => {
  if (message?.type === 'RESULTS_UPDATED') {
    const tab = await getActiveTab();
    if (tab?.id === message.tabId) {
      const response = await getResults(tab.id);
      renderAnalysis(response?.data || null);
    }
  }
});

// 초기 로드
refreshFromCurrentTab();
checkServerAuth();
