/* ============================================================
   Coupang Sourcing Helper — Content Script
   쿠팡 검색결과 페이지에서 상품 데이터를 파싱하여 background로 전달
   ============================================================ */
(function () {
  const MAX_ITEMS = 36;
  let debounceTimer = null;
  let lastSignature = '';

  function text(el) {
    return (el?.textContent || '').replace(/\s+/g, ' ').trim();
  }

  function getQuery() {
    const url = new URL(location.href);
    return url.searchParams.get('q') || document.querySelector('input[type="search"]')?.value || '';
  }

  function parseNumber(str) {
    if (!str) return 0;
    return parseInt(str.replace(/[^0-9]/g, ''), 10) || 0;
  }

  function parseFloat2(str) {
    if (!str) return 0;
    const m = str.match(/[\d.]+/);
    return m ? parseFloat(m[0]) : 0;
  }

  function parseProducts() {
    const products = [];

    const candidateSelectors = [
      'li.search-product',
      'li[class*="search-product"]',
      '[data-sentry-component="ProductUnit"]',
      'div[class*="search-product"]'
    ];

    const nodes = Array.from(document.querySelectorAll(candidateSelectors.join(',')));

    for (const node of nodes) {
      if (products.length >= MAX_ITEMS) break;

      // 광고 상품 체크
      const adBadge = node.querySelector('[class*="ad-badge"]') || node.querySelector('[class*="ad_badge"]');
      const isAd = !!adBadge || node.classList.contains('search-product__ad');

      const linkEl = node.querySelector('a[href*="/vp/products/"]') || node.querySelector('a.search-product-link');
      const titleEl = node.querySelector('.name') || node.querySelector('[class*="name"]') || linkEl;
      const priceEl = node.querySelector('.price-value') || node.querySelector('[class*="price"]');
      const ratingEl = node.querySelector('.rating') || node.querySelector('[class*="rating"]');
      const reviewEl = node.querySelector('.rating-total-count') || node.querySelector('[class*="review"]');
      const imageEl = node.querySelector('img');
      const rocketBadge = node.querySelector('[class*="rocket"]') || node.querySelector('img[alt*="로켓"]');

      const href = linkEl?.href || '';
      if (!href) continue;

      const productIdMatch = href.match(/\/vp\/products\/(\d+)/);
      const productId = productIdMatch ? productIdMatch[1] : null;
      const priceRaw = text(priceEl);
      const ratingRaw = text(ratingEl);
      const reviewRaw = text(reviewEl).replace(/[()]/g, '');

      const item = {
        productId,
        title: text(titleEl),
        price: parseNumber(priceRaw),
        priceText: priceRaw,
        rating: parseFloat2(ratingRaw),
        ratingText: ratingRaw,
        reviewCount: parseNumber(reviewRaw),
        reviewText: reviewRaw,
        url: href,
        imageUrl: imageEl?.src || imageEl?.getAttribute('data-img-src') || '',
        position: products.length + 1,
        query: getQuery(),
        isAd,
        isRocket: !!rocketBadge
      };

      if (!item.title && !item.price) continue;
      products.push(item);
    }

    return products;
  }

  function publishResults() {
    const items = parseProducts();
    const query = getQuery();
    const signature = JSON.stringify({ query, ids: items.map(i => i.productId || i.url) });

    if (signature === lastSignature) return;
    lastSignature = signature;

    chrome.runtime.sendMessage({
      type: 'SEARCH_RESULTS_PARSED',
      query,
      items
    }).catch(() => {});
  }

  function schedulePublish() {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(publishResults, 600);
  }

  const observer = new MutationObserver(() => schedulePublish());
  observer.observe(document.documentElement, {
    childList: true,
    subtree: true
  });

  window.addEventListener('load', schedulePublish);
  document.addEventListener('visibilitychange', schedulePublish);
  schedulePublish();
})();
