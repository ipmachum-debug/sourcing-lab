/* ============================================================
   Coupang Sourcing Helper — Server API Client
   lumiriz.kr 서버와 통신하는 API 클라이언트
   ============================================================ */

const API_BASE = 'https://lumiriz.kr/api/trpc';

class ApiClient {
  constructor() {
    this._sessionCookie = null;
  }

  // 서버에 로그인 (이메일/비밀번호)
  async login(email, password) {
    const resp = await this._call('auth.login', { email, password }, 'mutation');
    if (resp?.result?.data?.success) {
      await chrome.storage.local.set({ serverLoggedIn: true, serverEmail: email });
      return { success: true, user: resp.result.data.user };
    }
    throw new Error(resp?.error?.message || '로그인 실패');
  }

  // 현재 로그인 상태 확인
  async checkAuth() {
    try {
      const resp = await this._call('auth.me', undefined, 'query');
      const user = resp?.result?.data;
      if (user) {
        await chrome.storage.local.set({ serverLoggedIn: true });
        return { loggedIn: true, user };
      }
      await chrome.storage.local.set({ serverLoggedIn: false });
      return { loggedIn: false, user: null };
    } catch (e) {
      await chrome.storage.local.set({ serverLoggedIn: false });
      return { loggedIn: false, user: null };
    }
  }

  // 검색 스냅샷 저장
  async saveSnapshot(data) {
    return this._call('extension.saveSnapshot', data, 'mutation');
  }

  // 후보 저장
  async saveCandidate(item) {
    return this._call('extension.saveCandidate', item, 'mutation');
  }

  // 후보 삭제
  async removeCandidate(id) {
    return this._call('extension.removeCandidate', { id }, 'mutation');
  }

  // 후보 목록 조회
  async listCandidates(opts = {}) {
    return this._call('extension.listCandidates', opts, 'query');
  }

  // 후보를 소싱 상품으로 승격
  async promoteToProduct(candidateId) {
    return this._call('extension.promoteToProduct', { candidateId }, 'mutation');
  }

  // 검색 통계
  async searchStats() {
    return this._call('extension.searchStats', undefined, 'query');
  }

  // 후보 통계
  async candidateStats() {
    return this._call('extension.candidateStats', undefined, 'query');
  }

  // 검색 히스토리 조회
  async listSnapshots(opts = {}) {
    return this._call('extension.listSnapshots', opts, 'query');
  }

  // ---- 내부 통신 ----
  async _call(procedure, input, type = 'query') {
    const url = type === 'query'
      ? `${API_BASE}/${procedure}${input ? '?input=' + encodeURIComponent(JSON.stringify({ json: input })) : ''}`
      : `${API_BASE}/${procedure}`;

    const options = {
      method: type === 'query' ? 'GET' : 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
    };

    if (type !== 'query' && input !== undefined) {
      options.body = JSON.stringify({ json: input });
    }

    const resp = await fetch(url, options);
    if (!resp.ok) {
      const errBody = await resp.json().catch(() => ({}));
      const msg = errBody?.[0]?.error?.message || errBody?.error?.message || `HTTP ${resp.status}`;
      throw new Error(msg);
    }

    const data = await resp.json();
    // tRPC 배치 응답 형식 처리
    if (Array.isArray(data)) return data[0];
    return data;
  }
}

// 싱글톤
const apiClient = new ApiClient();
